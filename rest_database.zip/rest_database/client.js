const apiUrl = 'http://localhost:3000/api/users';
const usersData = document.getElementById('usersData');

async function getUsers(){
    try {
        const response = await fetch(apiUrl);
        const users = await response.json();

        usersData.innerHTML = users.map(user => `
            <tr>
                <td>${user.id}</td>
                <td>${user.firstName}</td>
                <td>${user.lastName}</td>
                <td>${user.city}</td>
                <td>${user.address}</td>
                <td>${user.phone}</td>
                <td>${user.email}</td>
                <td>${user.gender}</td>
                <td>
                <button onClick="editUsers(${user.id}, '${user.firstName}', '${user.lastName}', '${user.city}', '${user.address}', '${user.phone}', '${user.email}', '${user.gender}')">Módosítás</button>
                <button onClick="deleteUser(${user.id})">Törlés</button>
                </td>
            </tr>
            `).join('');
    }
    catch(e){
        console.error('Hiba a felhasználók lekérése során:', e);
    }
}

// adatok küldése az API-nak

document.getElementById('userForm').addEventListener('submit', async (e) =>{
    // Az alapértelmezett űrlap viselkedés kikapcsolása
    e.preventDefault();
    try{
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);

        //Az input elemek kitöltöttségének az ellenőrzése
        if (!data.firstName || !data.lastName || !data.city || !data.address || !data.phone || !data.email || !data.gender) {
            alert('Hiányzó adatok!');
        }
        else{
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            // várunk a szerver api válaszára
            const result = await response.json();

            //api válasza függőben
            if (response.ok) {
                alert(result.message); // Válaszüzenet megjelenítése
                getUsers(); // A HTML táblázat frissítése
            }
            else{
                alert(result.message); // válaszüzenet megjelenítése
            }
            e.target.reset();
        }
    }
    catch(e){

    }
})

//Felhasználói adatok módosítása
async function editUsers(id, firstName, lastName, city, address, phone, email, gender){
    //Az új adatok megadása
    const newFirstName = prompt('Add meg az új vezetéknevet:', firstName);
    const newLastName = prompt('Add meg az új keresztnevet:', lastName);
    const newCity = prompt('Add meg az új települést:', city);
    const newAddress = prompt('Add meg az új címet:', address);
    const newPhone = prompt('Add meg az új telefonszámot:', phone);
    const newEmail = prompt('Add meg az új email címet:', email);
    const newGender = prompt('Add meg az új nemet:', gender);

    if (newFirstName && newLastName && newCity && newAddress && newPhone && newEmail && newGender){
        try{
            const response = await fetch(`${apiUrl}/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ firstName: newFirstName, lastName: newLastName, city: newCity, address: newAddress, phone: newPhone, email: newEmail, gender: newGender})
            });
            if (response.ok){
                getUsers();
            }
            else{
                console.error('Hiba történt a felhasználó adatainak a törlése során!', await response.json())
            }
        }
        catch(e){
            alert('Nem sikerült a felhasználó adatait frissíteni!')
            console.error('Nem sikerült a felhasználó adatait frissíteni!', error)
        }
    }
}

//A felhasználói adatok törlése
async function deleteUser(id) {
    if (confirm('Valóban törölni akarok a felhaszálót?')) {
       try {
            const response = await fetch(`${apiUrl}/${id}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                getUsers();
            }
            else {
                console.error('Hiba történt a felhasználó törlése során!', await response.json());
            }
       }
       catch(e){
            alert('Az adatok törlése sikertelen volt!')
            console.error('Az adatok törlése sikertelen volt!', error)
       } 
    }
}

getUsers();